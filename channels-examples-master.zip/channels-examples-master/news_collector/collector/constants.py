
BLOGS = {
    "Django": "http://djangoproject.com/",
    "Python": "https://www.python.org/",
    "Mashable": "http://mashable.com/",
    "Gizmodo": "http://gizmodo.com/",
    "GigaOM": "http://gigaom.com/",
    "ZDNet": "http://www.zdnet.com/",
    "Computerworld Blogs": "http://blogs.computerworld.com/",
    "Official Google Enterprise Blog": "http://www.blog.google/",
    "The Unofficial Apple Weblog": "http://www.tuaw.com/",
    "How-To Geek": "http://www.howtogeek.com/",
    "ITBusinessEdge.com": "http://www.itbusinessedge.com/",
}
